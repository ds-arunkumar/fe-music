const AdminDashboard = () => {
  return (
    <div>
      <h1 className="text-center text-3xl font-semibold text-gray-800">Admin Dashboard</h1>
    </div>
  )
}

export default AdminDashboard;